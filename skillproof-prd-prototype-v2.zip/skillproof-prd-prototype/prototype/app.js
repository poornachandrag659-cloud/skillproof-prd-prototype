const STORAGE_KEY = "skillproof.cards.v1";

const demoCards = [
  {id:"demo-1",name:"Python",level:"Intermediate",evidenceType:"GitHub",url:"https://github.com/",note:"Built small data-analysis scripts and practiced core programming concepts.",status:"Evidence added",createdAt:"2026-10-01T10:00:00.000Z"},
  {id:"demo-2",name:"Product thinking",level:"Beginner",evidenceType:"Project",url:"",note:"Practiced writing user stories, defining an MVP, and choosing measurable outcomes.",status:"Draft",createdAt:"2026-10-02T10:00:00.000Z"},
  {id:"demo-3",name:"Data analysis",level:"Intermediate",evidenceType:"Project",url:"https://github.com/",note:"Explored feedback themes and translated observations into product recommendations.",status:"Ready to share",createdAt:"2026-10-03T10:00:00.000Z"},
  {id:"demo-4",name:"HTML & CSS",level:"Intermediate",evidenceType:"Work sample",url:"",note:"Created responsive page layouts and reusable UI components.",status:"Evidence added",createdAt:"2026-10-04T10:00:00.000Z"}
];

const $ = (id) => document.getElementById(id);
const skillDialog = $("skillDialog");
const profileDialog = $("profileDialog");
let cards = loadCards();
let toastTimer;

function loadCards() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : structuredClone(demoCards);
  } catch {
    return structuredClone(demoCards);
  }
}
function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cards)); }
  catch { showToast("Browser storage is unavailable. Changes may not persist."); }
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function safeUrl(raw) {
  try {
    const url = new URL(raw);
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}
function initials(name) {
  const words = name.trim().split(/\s+/).filter(Boolean);
  return (words.length > 1 ? words[0][0] + words[1][0] : (words[0] || "S").slice(0,2)).toUpperCase();
}
function iconFor(type) {
  return ({GitHub:"⌘",Project:"↗",Certificate:"✦","Work sample":"▤",Other:"◇"})[type] || "◇";
}
function statusClass(status) {
  return status === "Draft" ? "draft" : status === "Ready to share" ? "ready" : "evidence";
}
function render() {
  const query = $("searchInput").value.trim().toLowerCase();
  const status = $("statusFilter").value;
  const visible = cards.filter(card => {
    const matchesQuery = `${card.name} ${card.note} ${card.evidenceType}`.toLowerCase().includes(query);
    return matchesQuery && (status === "all" || card.status === status);
  });
  $("totalCount").textContent = cards.length;
  $("evidenceCount").textContent = cards.filter(c => Boolean(safeUrl(c.url)) || c.note.trim()).length;
  $("draftCount").textContent = cards.filter(c => c.status === "Draft").length;
  $("visibleCount").textContent = `${visible.length} ${visible.length === 1 ? "skill" : "skills"}`;
  $("skillsGrid").innerHTML = visible.map(card => {
    const url = safeUrl(card.url);
    const evidenceLabel = url ? escapeHtml(card.url) : (card.note.trim() ? "Context note added" : "No evidence added yet");
    return `<article class="skill-card">
      <div class="card-top"><div class="skill-heading"><div class="skill-symbol">${escapeHtml(initials(card.name))}</div><div><h3>${escapeHtml(card.name)}</h3><span class="skill-level">${escapeHtml(card.level)} · Self-assessed</span></div></div><span class="status ${statusClass(card.status)}">${escapeHtml(card.status)}</span></div>
      <p class="skill-note">${escapeHtml(card.note || "Add a short note explaining how you have used this skill.")}</p>
      <div class="evidence-row"><div class="evidence-icon">${iconFor(card.evidenceType)}</div><div class="evidence-meta"><strong>${escapeHtml(card.evidenceType)} evidence</strong>${url ? `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${evidenceLabel}</a>` : `<small>${evidenceLabel}</small>`}</div><div class="card-actions"><button data-edit="${escapeHtml(card.id)}" aria-label="Edit ${escapeHtml(card.name)}">Edit</button><button data-delete="${escapeHtml(card.id)}" aria-label="Delete ${escapeHtml(card.name)}">×</button></div></div>
      <div class="card-bottom"><span class="evidence-label">${url ? "↗ Link supplied" : "○ User-submitted details"}</span><button class="ready-toggle" data-status="${escapeHtml(card.id)}">${card.status === "Ready to share" ? "Mark as draft" : "Mark ready →"}</button></div>
    </article>`;
  }).join("");
  $("emptyState").classList.toggle("hidden", visible.length !== 0);
  $("skillsGrid").style.display = visible.length ? "grid" : "none";
}
function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function openAdd() {
  $("skillForm").reset();
  $("skillId").value = "";
  $("dialogTitle").textContent = "Add a skill";
  $("skillLevel").value = "Intermediate";
  skillDialog.showModal();
  $("skillName").focus();
}
function openEdit(id) {
  const card = cards.find(c => c.id === id);
  if (!card) return;
  $("skillId").value = card.id;
  $("skillName").value = card.name;
  $("skillLevel").value = card.level;
  $("evidenceType").value = card.evidenceType;
  $("evidenceUrl").value = card.url;
  $("skillNote").value = card.note;
  $("dialogTitle").textContent = "Edit skill";
  skillDialog.showModal();
}
function openProfile() {
  $("profileSkillCount").textContent = `${cards.length} ${cards.length === 1 ? "skill" : "skills"}`;
  $("profileSkills").innerHTML = cards.length ? cards.map(card => {
    const url = safeUrl(card.url);
    return `<article class="profile-skill"><div class="profile-skill-head"><strong>${escapeHtml(card.name)}</strong><span class="status ${statusClass(card.status)}">${escapeHtml(card.status)}</span></div><p>${escapeHtml(card.note || "No context note supplied.")}</p>${url ? `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">View user-submitted ${escapeHtml(card.evidenceType.toLowerCase())} ↗</a>` : `<span class="evidence-label">No external link supplied</span>`}</article>`;
  }).join("") : `<p class="evidence-label">Add a skill to start your profile.</p>`;
  profileDialog.showModal();
}
$("openAddBtn").addEventListener("click", openAdd);
$("emptyAddBtn").addEventListener("click", openAdd);
$("closeDialog").addEventListener("click", () => skillDialog.close());
$("cancelBtn").addEventListener("click", () => skillDialog.close());
$("closeProfile").addEventListener("click", () => profileDialog.close());
$("navProfile").addEventListener("click", openProfile);
$("navDashboard").addEventListener("click", () => { profileDialog.close(); window.scrollTo({top:0,behavior:"smooth"}); });
$("searchInput").addEventListener("input", render);
$("statusFilter").addEventListener("change", render);

$("skillForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = $("skillName").value.trim();
  if (!name) { $("skillName").focus(); return; }
  const urlRaw = $("evidenceUrl").value.trim();
  const url = urlRaw ? safeUrl(urlRaw) : "";
  if (urlRaw && !url) { showToast("Enter a valid http or https link."); $("evidenceUrl").focus(); return; }
  const note = $("skillNote").value.trim();
  const id = $("skillId").value;
  const previous = cards.find(c => c.id === id);
  const status = (url || note) ? (previous?.status === "Ready to share" ? "Ready to share" : "Evidence added") : "Draft";
  const card = {id: id || `skill-${Date.now()}`, name, level:$("skillLevel").value, evidenceType:$("evidenceType").value, url, note, status, createdAt:previous?.createdAt || new Date().toISOString()};
  if (id) cards = cards.map(c => c.id === id ? card : c);
  else cards.unshift(card);
  persist(); render(); skillDialog.close(); showToast(id ? "Skill updated." : "Skill added to your portfolio.");
});
$("skillsGrid").addEventListener("click", event => {
  const edit = event.target.closest("[data-edit]");
  const del = event.target.closest("[data-delete]");
  const statusBtn = event.target.closest("[data-status]");
  if (edit) openEdit(edit.dataset.edit);
  if (del) {
    const card = cards.find(c => c.id === del.dataset.delete);
    if (card && confirm(`Delete the "${card.name}" skill card?`)) {
      cards = cards.filter(c => c.id !== card.id); persist(); render(); showToast("Skill removed.");
    }
  }
  if (statusBtn) {
    const id = statusBtn.dataset.status;
    cards = cards.map(c => c.id === id ? {...c, status:c.status === "Ready to share" ? (safeUrl(c.url) || c.note.trim() ? "Evidence added" : "Draft") : "Ready to share"} : c);
    persist(); render(); showToast("Skill status updated.");
  }
});
$("resetBtn").addEventListener("click", () => {
  if (confirm("Restore the sample portfolio? This replaces the cards saved in this browser.")) {
    cards = structuredClone(demoCards); persist(); render(); showToast("Demo portfolio restored.");
  }
});
render();
