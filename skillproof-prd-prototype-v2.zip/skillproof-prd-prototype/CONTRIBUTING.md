# Contributing

This repository is a portfolio prototype. Suggestions and small improvements are welcome.

1. Describe the user problem your change addresses.
2. Keep the prototype dependency-free unless a clear need is demonstrated.
3. Do not imply that user-submitted evidence is independently verified.
4. Test add/edit/delete, search/filter, profile preview, persistence, reset, and mobile layout.
5. Update the README or PRD when behavior or scope changes.
