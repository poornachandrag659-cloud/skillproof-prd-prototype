# SkillProof — Evidence-Based Skills Portfolio

> A product-management portfolio project: a complete PRD, a responsive interactive prototype, and a user-validation plan.

SkillProof helps students and early-career professionals connect skill claims to supporting examples such as projects, repositories, certificates, and work samples.

**Trust note:** Evidence is supplied by the user. This prototype does not independently verify credentials, links, identity, or skill proficiency.

## Live demo

After GitHub Pages is enabled, the repository root redirects to the app in [`prototype/`](prototype/).

## Features

- Skills dashboard and summary counts
- Add, edit, and delete skill cards
- Self-assessed skill levels and evidence references
- Search and status filters
- Profile preview
- Browser-local persistence and reset-to-demo action
- Responsive desktop/mobile layout

## Project documents

- [Product Requirements Document](PRD.md)
- [Validation plan](docs/validation-plan.md)
- [Metrics plan](docs/metrics.md)
- [Prototype source](prototype/index.html)

## Run locally

No build step, API key, backend, or database is required.

```bash
python -m http.server 8000
```

Open `http://localhost:8000/`. The root page forwards to `prototype/`. Alternatively, open `prototype/index.html` directly.

## Deploy with GitHub Pages

A workflow is included at `.github/workflows/pages.yml`.

1. Push this repository to the `main` branch.
2. Open **Settings → Pages** in GitHub.
3. Under **Build and deployment**, select **GitHub Actions** as the source.
4. Open **Actions** and wait for `Deploy SkillProof to GitHub Pages` to succeed.
5. The workflow summary will show the published URL.

## Tech stack

HTML5 · CSS3 · Vanilla JavaScript · `localStorage` · GitHub Pages

## Product decisions

- **Evidence over inflated claims:** the UI labels evidence as user-submitted.
- **Narrow MVP:** no sign-in, cloud sync, AI scoring, scraping, or third-party verification.
- **Validate before scaling:** test the core workflow before adding a backend.

## Known limitations

- Data stays in the current browser and is not synced across devices.
- External links are not fetched or checked.
- This is a concept prototype, not a production identity or credential-verification system.
- Browser-local data should not contain sensitive or confidential information.

## Validation targets

The PRD proposes usability targets, not measured outcomes. See [`docs/validation-plan.md`](docs/validation-plan.md).

## Resume bullet

Designed a PRD and built a responsive, interactive skills-portfolio prototype; defined user stories, MVP scope, acceptance criteria, validation hypotheses, and success metrics.

## License

MIT — see [`LICENSE`](LICENSE).
